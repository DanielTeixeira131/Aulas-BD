
package model;

public class cliente {
    private char cpf;
    private String nome;
    private double historicodecompras;
    private int numerodecompras;

    public char getCpf() {
        return cpf;
    }

    public void setCpf(char cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getHistoricodecompras() {
        return historicodecompras;
    }

    public void setHistoricodecompras(double historicodecompras) {
        this.historicodecompras = historicodecompras;
    }

    public int getNumerodecompras() {
        return numerodecompras;
    }

    public void setNumerodecompras(int numerodecompras) {
        this.numerodecompras = numerodecompras;
    }

    public cliente(char cpf, String nome, double historicodecompras, int numerodecompras) {
        this.cpf = cpf;
        this.nome = nome;
        this.historicodecompras = historicodecompras;
        this.numerodecompras = numerodecompras;
    }

    public cliente() {
        this.cpf = 0;
        this.nome = null;
        this.historicodecompras = 0;
        this.numerodecompras = 0;
    }
    
}
