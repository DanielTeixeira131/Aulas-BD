
package model;

public class empregado {
    private double salario;
    private char cpf;

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }

    public char getCpf() {
        return cpf;
    }

    public void setCpf(char cpf) {
        this.cpf = cpf;
    }

    public empregado(double salario, char cpf) {
        this.salario = 0;
        this.cpf = 0;
    }
    
}
